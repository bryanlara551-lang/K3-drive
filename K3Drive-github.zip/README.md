# K3 Drive

Central multimedia y de conducción para Samsung Galaxy Tab A9+ (Kia K3). Kotlin + Jetpack Compose + Room. Sin Firebase ni servidores propios.

## Obtener el APK desde GitHub (sin Android Studio)
1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta a la rama `main`.
2. Abre la pestaña **Actions**: el flujo **Build APK** se ejecuta solo (~5 min). También puedes lanzarlo con *Run workflow*.
3. Al terminar, entra a la ejecución y descarga **K3Drive-debug-apk** en *Artifacts* (es un ZIP con `K3Drive-debug.apk`).
4. Cópialo a la tablet e instálalo (permite "instalar apps desconocidas" para tu navegador o gestor de archivos).

### APK como Release descargable
Crea una etiqueta y súbela: `git tag v0.1.0 && git push origin v0.1.0`.
El APK aparece en la sección **Releases** del repositorio.

## Compilar localmente
Abre la carpeta en Android Studio (Koala+), espera el Gradle Sync y pulsa Run, o Build > Build APK(s).

## Configuración
Al abrir, concede Ubicación (velocidad GPS) y Bluetooth. Sin ubicación la velocidad muestra "No disponible".

## Implementado (Fase 1)
- Dashboard horizontal a pantalla completa: reloj, fecha, clima (Open-Meteo), batería, Bluetooth de audio.
- Velocímetro por GPS, distancia y tiempo de viaje.
- Ilustración vectorial propia del sedán Steel Gray.
- 10 accesos directos detectados con PackageManager, con orden y visibilidad guardados en Room.
- RPM, odómetro, combustible y temperatura: "No disponible" (sin fuente real aún).

## Pendiente
Fase 2 NEX voz · Fase 3 multimedia y modo nocturno · Fase 4 NEX Guard · Fase 5 perfil y rutas · Fase 6 OBD-II.
