package com.k3drive.data

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppDef(
    val id: String,
    val label: String,
    val packages: List<String>,
    val keywordSets: List<List<String>> = emptyList(),
    val fallbackAction: String? = null,
)

data class ResolvedApp(val def: AppDef, val intent: Intent?, val icon: ImageBitmap?)

object AppCatalog {
    val all = listOf(
        AppDef("didi", "DiDi Conductor", listOf("com.didiglobal.driver"), listOf(listOf("didi", "conductor"), listOf("didi", "driver"))),
        AppDef("apple_music", "Apple Music", listOf("com.apple.android.music")),
        AppDef("maps", "Google Maps", listOf("com.google.android.apps.maps")),
        AppDef("waze", "Waze", listOf("com.waze")),
        AppDef("youtube", "YouTube", listOf("com.google.android.youtube")),
        AppDef("ytmusic", "YouTube Music", listOf("com.google.android.apps.youtube.music")),
        AppDef("spotify", "Spotify", listOf("com.spotify.music")),
        AppDef("whatsapp", "WhatsApp", listOf("com.whatsapp")),
        AppDef("phone", "Teléfono", listOf("com.samsung.android.dialer", "com.google.android.dialer"), fallbackAction = Intent.ACTION_DIAL),
        AppDef("settings", "Configuración", listOf("com.android.settings"), fallbackAction = Settings.ACTION_SETTINGS),
    )

    /** Detecta cuáles están instaladas usando solo PackageManager (mecanismo oficial). */
    fun resolve(ctx: Context): Map<String, ResolvedApp> {
        val pm = ctx.packageManager
        val launchables = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        return all.associate { d ->
            var pkg = d.packages.firstOrNull { pm.getLaunchIntentForPackage(it) != null }
            if (pkg == null) {
                pkg = launchables.firstOrNull { ri ->
                    val l = ri.loadLabel(pm).toString().lowercase()
                    d.keywordSets.any { set -> set.all { l.contains(it) } }
                }?.activityInfo?.packageName
            }
            val intent = when {
                pkg != null -> pm.getLaunchIntentForPackage(pkg)
                d.fallbackAction != null -> Intent(d.fallbackAction)
                else -> null
            }
            val icon = pkg?.let {
                runCatching { pm.getApplicationIcon(it).toBitmap(96, 96).asImageBitmap() }.getOrNull()
            }
            d.id to ResolvedApp(d, intent, icon)
        }
    }
}
