package com.k3drive.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

@Composable
fun Speedo(speed: Int?, modifier: Modifier = Modifier) {
    val maxKmh = 180f
    val target = ((speed ?: 0) / maxKmh).coerceIn(0f, 1f)
    val frac by animateFloatAsState(target, tween(400), label = "speed")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().aspectRatio(1f)) {
            val stroke = size.minDimension * 0.07f
            val d = size.minDimension - stroke
            val tl = Offset((size.width - d) / 2, (size.height - d) / 2)
            val sz = Size(d, d)
            drawArc(Color(0xFF1B2330), 150f, 240f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            if (speed != null) {
                drawArc(
                    Brush.sweepGradient(listOf(Color(0xFF0066FF), Electric, Color(0xFF7DF9FF), Electric), center),
                    150f, 240f * frac, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (speed != null) {
                Text("$speed", fontSize = 64.sp, fontWeight = FontWeight.Light, color = androidx.compose.ui.graphics.Color.White)
                Text("km/h", fontSize = 16.sp, color = Electric)
            } else {
                Text("—", fontSize = 56.sp, color = Dim)
                Text("No disponible", fontSize = 13.sp, color = Dim)
            }
        }
    }
}

/** Ilustración vectorial propia de un sedán en color Steel Gray (no es un render oficial de Kia). */
@Composable
fun Car(modifier: Modifier = Modifier) {
    val glow by rememberInfiniteTransition(label = "glow").animateFloat(
        0.55f, 1f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g"
    )
    Canvas(modifier.aspectRatio(2.6f)) {
        val w = size.width; val h = size.height
        // luz inferior
        drawOval(
            Brush.radialGradient(listOf(Electric.copy(alpha = 0.55f * glow), Color.Transparent), Offset(w / 2, h * 0.93f), w * 0.5f),
            Offset(w * 0.05f, h * 0.80f), Size(w * 0.9f, h * 0.2f)
        )
        val body = Path().apply {
            moveTo(0.05f * w, 0.70f * h); lineTo(0.06f * w, 0.52f * h); lineTo(0.20f * w, 0.46f * h)
            lineTo(0.30f * w, 0.46f * h); quadraticBezierTo(0.36f * w, 0.20f * h, 0.46f * w, 0.18f * h)
            lineTo(0.60f * w, 0.18f * h); quadraticBezierTo(0.70f * w, 0.21f * h, 0.76f * w, 0.44f * h)
            lineTo(0.92f * w, 0.50f * h); quadraticBezierTo(0.97f * w, 0.54f * h, 0.97f * w, 0.64f * h)
            lineTo(0.96f * w, 0.70f * h); close()
        }
        drawPath(body, Brush.verticalGradient(listOf(Color(0xFFB4BAC0), SteelGray, Color(0xFF4A4F55))))
        drawPath(body, Electric.copy(alpha = 0.35f), style = Stroke(2f))
        val glass = Path().apply {
            moveTo(0.33f * w, 0.45f * h); quadraticBezierTo(0.38f * w, 0.26f * h, 0.46f * w, 0.25f * h)
            lineTo(0.58f * w, 0.25f * h); quadraticBezierTo(0.66f * w, 0.27f * h, 0.71f * w, 0.45f * h); close()
        }
        drawPath(glass, Brush.verticalGradient(listOf(Color(0xFF1C3A52), Color(0xFF0A1622))))
        drawLine(SteelGray, Offset(0.52f * w, 0.25f * h), Offset(0.52f * w, 0.45f * h), 5f)
        drawRoundRect(Color(0xFFBFEFFF), Offset(0.92f * w, 0.52f * h), Size(0.045f * w, 0.05f * h), CornerRadius(6f))
        drawRoundRect(Color(0xFFFF3B3B), Offset(0.055f * w, 0.53f * h), Size(0.03f * w, 0.05f * h), CornerRadius(6f))
        for (cx in listOf(0.24f, 0.76f)) {
            val c = Offset(cx * w, 0.70f * h); val r = 0.09f * w
            drawCircle(Color(0xFF05070A), r * 1.15f, c)
            drawCircle(Color(0xFF1A1D21), r, c)
            drawCircle(Color(0xFFC9CED3), r * 0.68f, c)
            for (k in 0 until 5) {
                val a = Math.toRadians(k * 72.0 - 90)
                drawLine(Color(0xFF50565C), c, Offset(c.x + (r * 0.66f * cos(a)).toFloat(), c.y + (r * 0.66f * sin(a)).toFloat()), 7f)
            }
            drawCircle(Color(0xFF50565C), r * 0.14f, c)
        }
    }
}

@Composable
fun RainbowRing(modifier: Modifier = Modifier) {
    val angle by rememberInfiniteTransition(label = "rb").animateFloat(
        0f, 360f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "a"
    )
    Canvas(modifier) {
        rotate(angle) {
            drawCircle(
                Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)),
                size.minDimension / 2 - 4f, style = Stroke(8f)
            )
        }
    }
}
